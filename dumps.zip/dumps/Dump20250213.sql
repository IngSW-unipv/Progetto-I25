-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 34.67.192.34    Database: cacioKart
-- ------------------------------------------------------
-- Server version	8.0.37-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '4d5245ab-e923-11ef-abb9-42010a400002:1-535';

--
-- Table structure for table `acquisto`
--

DROP TABLE IF EXISTS `acquisto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acquisto` (
  `idProdotto` varchar(5) NOT NULL,
  `cf` char(16) NOT NULL,
  `giorno` date NOT NULL,
  PRIMARY KEY (`idProdotto`,`cf`,`giorno`),
  KEY `cf` (`cf`),
  CONSTRAINT `acquisto_ibfk_1` FOREIGN KEY (`idProdotto`) REFERENCES `concessionaria` (`idProdotto`),
  CONSTRAINT `acquisto_ibfk_2` FOREIGN KEY (`cf`) REFERENCES `socio` (`cf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acquisto`
--

LOCK TABLES `acquisto` WRITE;
/*!40000 ALTER TABLE `acquisto` DISABLE KEYS */;
/*!40000 ALTER TABLE `acquisto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apparteneza`
--

DROP TABLE IF EXISTS `apparteneza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apparteneza` (
  `nome` varchar(30) NOT NULL,
  `cf` char(16) NOT NULL,
  PRIMARY KEY (`nome`,`cf`),
  KEY `cf` (`cf`),
  CONSTRAINT `apparteneza_ibfk_1` FOREIGN KEY (`nome`) REFERENCES `team` (`nome`),
  CONSTRAINT `apparteneza_ibfk_2` FOREIGN KEY (`cf`) REFERENCES `socio` (`cf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apparteneza`
--

LOCK TABLES `apparteneza` WRITE;
/*!40000 ALTER TABLE `apparteneza` DISABLE KEYS */;
/*!40000 ALTER TABLE `apparteneza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campionato`
--

DROP TABLE IF EXISTS `campionato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campionato` (
  `idCampionato` varchar(5) NOT NULL,
  `anno` year DEFAULT NULL,
  PRIMARY KEY (`idCampionato`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campionato`
--

LOCK TABLES `campionato` WRITE;
/*!40000 ALTER TABLE `campionato` DISABLE KEYS */;
/*!40000 ALTER TABLE `campionato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `circuito`
--

DROP TABLE IF EXISTS `circuito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `circuito` (
  `idC` varchar(5) NOT NULL,
  `nome` varchar(30) DEFAULT NULL,
  `immagine` blob,
  `conformazione` int DEFAULT NULL,
  `lunghezza` double DEFAULT NULL,
  `idGS` varchar(5) DEFAULT NULL,
  `idGL` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`idC`),
  KEY `idGS` (`idGS`),
  KEY `idGL` (`idGL`),
  CONSTRAINT `circuito_ibfk_1` FOREIGN KEY (`idGS`) REFERENCES `garaS` (`idG`),
  CONSTRAINT `circuito_ibfk_2` FOREIGN KEY (`idGL`) REFERENCES `garaL` (`idG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `circuito`
--

LOCK TABLES `circuito` WRITE;
/*!40000 ALTER TABLE `circuito` DISABLE KEYS */;
/*!40000 ALTER TABLE `circuito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concessionaria`
--

DROP TABLE IF EXISTS `concessionaria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concessionaria` (
  `idProdotto` varchar(5) NOT NULL,
  `tipologia` varchar(100) DEFAULT NULL,
  `quantita` int DEFAULT NULL,
  `prezzo` double DEFAULT NULL,
  `cfDip` char(16) DEFAULT NULL,
  PRIMARY KEY (`idProdotto`),
  KEY `fk_cfDip` (`cfDip`),
  CONSTRAINT `fk_cfDip` FOREIGN KEY (`cfDip`) REFERENCES `dipendente` (`cf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concessionaria`
--

LOCK TABLES `concessionaria` WRITE;
/*!40000 ALTER TABLE `concessionaria` DISABLE KEYS */;
/*!40000 ALTER TABLE `concessionaria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dipendente`
--

DROP TABLE IF EXISTS `dipendente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dipendente` (
  `cf` char(16) NOT NULL,
  `nome` varchar(30) DEFAULT NULL,
  `cognome` varchar(30) DEFAULT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `dataN` date DEFAULT NULL,
  `ruolo` varchar(30) DEFAULT NULL,
  `oreL` double DEFAULT NULL,
  `stipendio` double DEFAULT NULL,
  PRIMARY KEY (`cf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dipendente`
--

LOCK TABLES `dipendente` WRITE;
/*!40000 ALTER TABLE `dipendente` DISABLE KEYS */;
/*!40000 ALTER TABLE `dipendente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eseguita`
--

DROP TABLE IF EXISTS `eseguita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eseguita` (
  `idManuten` varchar(5) NOT NULL,
  `cf` char(16) NOT NULL,
  PRIMARY KEY (`idManuten`,`cf`),
  KEY `cf` (`cf`),
  CONSTRAINT `eseguita_ibfk_1` FOREIGN KEY (`idManuten`) REFERENCES `manutenzione` (`idManuten`),
  CONSTRAINT `eseguita_ibfk_2` FOREIGN KEY (`cf`) REFERENCES `dipendente` (`cf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eseguita`
--

LOCK TABLES `eseguita` WRITE;
/*!40000 ALTER TABLE `eseguita` DISABLE KEYS */;
/*!40000 ALTER TABLE `eseguita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `garaL`
--

DROP TABLE IF EXISTS `garaL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `garaL` (
  `idG` varchar(5) NOT NULL,
  `ora` time DEFAULT NULL,
  `idP` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`idG`),
  KEY `idP` (`idP`),
  CONSTRAINT `garaL_ibfk_1` FOREIGN KEY (`idP`) REFERENCES `prenotazione` (`idP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `garaL`
--

LOCK TABLES `garaL` WRITE;
/*!40000 ALTER TABLE `garaL` DISABLE KEYS */;
/*!40000 ALTER TABLE `garaL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `garaS`
--

DROP TABLE IF EXISTS `garaS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `garaS` (
  `idG` varchar(5) NOT NULL,
  `ora` time DEFAULT NULL,
  `idP` varchar(5) DEFAULT NULL,
  `nPartecipanti` int DEFAULT NULL,
  `bTempo` time DEFAULT NULL,
  `classifica` blob,
  `idC` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`idG`),
  KEY `idP` (`idP`),
  CONSTRAINT `garaS_ibfk_1` FOREIGN KEY (`idP`) REFERENCES `prenotazione` (`idP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `garaS`
--

LOCK TABLES `garaS` WRITE;
/*!40000 ALTER TABLE `garaS` DISABLE KEYS */;
/*!40000 ALTER TABLE `garaS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iscrizione`
--

DROP TABLE IF EXISTS `iscrizione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iscrizione` (
  `idIscr` varchar(5) NOT NULL,
  `categoria` int DEFAULT NULL,
  `costo` double DEFAULT NULL,
  `cf` char(16) DEFAULT NULL,
  `nome` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idIscr`),
  KEY `nome` (`nome`),
  KEY `cf` (`cf`),
  CONSTRAINT `iscrizione_ibfk_1` FOREIGN KEY (`nome`) REFERENCES `team` (`nome`),
  CONSTRAINT `iscrizione_ibfk_2` FOREIGN KEY (`cf`) REFERENCES `socio` (`cf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iscrizione`
--

LOCK TABLES `iscrizione` WRITE;
/*!40000 ALTER TABLE `iscrizione` DISABLE KEYS */;
/*!40000 ALTER TABLE `iscrizione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kart`
--

DROP TABLE IF EXISTS `kart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kart` (
  `targa` varchar(7) NOT NULL,
  `cilindrata` int DEFAULT NULL,
  `serbatoio` double DEFAULT NULL,
  PRIMARY KEY (`targa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kart`
--

LOCK TABLES `kart` WRITE;
/*!40000 ALTER TABLE `kart` DISABLE KEYS */;
/*!40000 ALTER TABLE `kart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manutenere`
--

DROP TABLE IF EXISTS `manutenere`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manutenere` (
  `idManuten` varchar(5) NOT NULL,
  `targa` varchar(7) NOT NULL,
  PRIMARY KEY (`idManuten`,`targa`),
  KEY `targa` (`targa`),
  CONSTRAINT `manutenere_ibfk_1` FOREIGN KEY (`idManuten`) REFERENCES `manutenzione` (`idManuten`),
  CONSTRAINT `manutenere_ibfk_2` FOREIGN KEY (`targa`) REFERENCES `kart` (`targa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manutenere`
--

LOCK TABLES `manutenere` WRITE;
/*!40000 ALTER TABLE `manutenere` DISABLE KEYS */;
/*!40000 ALTER TABLE `manutenere` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manutenzione`
--

DROP TABLE IF EXISTS `manutenzione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manutenzione` (
  `idManuten` varchar(5) NOT NULL,
  `costo` double DEFAULT NULL,
  `tipoInte` varchar(1000) DEFAULT NULL,
  `dataI` date DEFAULT NULL,
  PRIMARY KEY (`idManuten`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manutenzione`
--

LOCK TABLES `manutenzione` WRITE;
/*!40000 ALTER TABLE `manutenzione` DISABLE KEYS */;
/*!40000 ALTER TABLE `manutenzione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partecipazione`
--

DROP TABLE IF EXISTS `partecipazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partecipazione` (
  `idG` varchar(5) NOT NULL,
  `idCampionato` varchar(5) NOT NULL,
  PRIMARY KEY (`idG`,`idCampionato`),
  CONSTRAINT `partecipazione_ibfk_1` FOREIGN KEY (`idG`) REFERENCES `garaS` (`idG`),
  CONSTRAINT `partecipazione_ibfk_2` FOREIGN KEY (`idG`) REFERENCES `garaS` (`idG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partecipazione`
--

LOCK TABLES `partecipazione` WRITE;
/*!40000 ALTER TABLE `partecipazione` DISABLE KEYS */;
/*!40000 ALTER TABLE `partecipazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posseduto`
--

DROP TABLE IF EXISTS `posseduto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posseduto` (
  `targa` varchar(7) NOT NULL,
  `cf` char(16) NOT NULL,
  PRIMARY KEY (`targa`,`cf`),
  KEY `cf` (`cf`),
  CONSTRAINT `posseduto_ibfk_1` FOREIGN KEY (`targa`) REFERENCES `kart` (`targa`),
  CONSTRAINT `posseduto_ibfk_2` FOREIGN KEY (`cf`) REFERENCES `socio` (`cf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posseduto`
--

LOCK TABLES `posseduto` WRITE;
/*!40000 ALTER TABLE `posseduto` DISABLE KEYS */;
/*!40000 ALTER TABLE `posseduto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prenota`
--

DROP TABLE IF EXISTS `prenota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prenota` (
  `cf` char(16) NOT NULL,
  `idP` varchar(5) NOT NULL,
  PRIMARY KEY (`cf`,`idP`),
  KEY `idP` (`idP`),
  CONSTRAINT `prenota_ibfk_1` FOREIGN KEY (`cf`) REFERENCES `socio` (`cf`),
  CONSTRAINT `prenota_ibfk_2` FOREIGN KEY (`idP`) REFERENCES `prenotazione` (`idP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prenota`
--

LOCK TABLES `prenota` WRITE;
/*!40000 ALTER TABLE `prenota` DISABLE KEYS */;
/*!40000 ALTER TABLE `prenota` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prenotazione`
--

DROP TABLE IF EXISTS `prenotazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prenotazione` (
  `idP` varchar(5) NOT NULL,
  `dataP` date DEFAULT NULL,
  `datG` date DEFAULT NULL,
  `FasciaO` time DEFAULT NULL,
  `tipoG` varchar(5) DEFAULT NULL,
  `costo` double DEFAULT NULL,
  `nPartecipanti` int DEFAULT NULL,
  PRIMARY KEY (`idP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prenotazione`
--

LOCK TABLES `prenotazione` WRITE;
/*!40000 ALTER TABLE `prenotazione` DISABLE KEYS */;
/*!40000 ALTER TABLE `prenotazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `socio`
--

DROP TABLE IF EXISTS `socio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `socio` (
  `cf` char(16) NOT NULL,
  `nome` varchar(30) DEFAULT NULL,
  `cognome` varchar(30) DEFAULT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `dataN` date DEFAULT NULL,
  PRIMARY KEY (`cf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `socio`
--

LOCK TABLES `socio` WRITE;
/*!40000 ALTER TABLE `socio` DISABLE KEYS */;
/*!40000 ALTER TABLE `socio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sostenuta`
--

DROP TABLE IF EXISTS `sostenuta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sostenuta` (
  `idIscr` varchar(5) NOT NULL,
  `idG` varchar(5) NOT NULL,
  PRIMARY KEY (`idIscr`,`idG`),
  KEY `idG` (`idG`),
  CONSTRAINT `sostenuta_ibfk_1` FOREIGN KEY (`idIscr`) REFERENCES `iscrizione` (`idIscr`),
  CONSTRAINT `sostenuta_ibfk_2` FOREIGN KEY (`idG`) REFERENCES `garaS` (`idG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sostenuta`
--

LOCK TABLES `sostenuta` WRITE;
/*!40000 ALTER TABLE `sostenuta` DISABLE KEYS */;
/*!40000 ALTER TABLE `sostenuta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `nome` varchar(30) NOT NULL,
  `colore` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-13 14:48:51
